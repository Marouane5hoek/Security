<?php

require 'db.php';

class User
{
    public $dbh;
    public $table = 'users';

    public $message;

    public function __construct(DB $dbh)
    {
        $this->dbh = $dbh;
        session_start();
    }

    public function hash($password): string
    {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        return $hash;
    }

    public function all(): array
    {
        return $this->dbh->run("SELECT * from $this->table")->fetchAll();
    }

    public function first($id): array
    {
        $qeury = $this->dbh->run("SELECT * from $this->table where id = :id", ['id' => $id]);
        return $qeury->fetch();
    }

    public function add($email, $password): int
    {
        // prevent xss
        $email = filter_var($email, FILTER_SANITIZE_EMAIL);

        if ($email) {
            $hash = $this->hash($password);
            $qeury = $this->dbh->run("INSERT INTO $this->table (email, password) VALUES (':email', ':password')", ['email' => $email, 'password' => $hash]);
            return $this->dbh->lastId();
        } else {
            throw new Exception("Fout bij het toevoegen");
        }
    }

    public function edit($email, $password, $id): PDOStatement
    {
        $hash = $this->hash($password);
        $qeury = $this->dbh->run("UPDATE $this->table SET email =':email', password = ':password' WHERE id = :id", ['email' => $email, 'password' => $hash, 'id' => $id]);
        return $qeury;
    }

    public function delete($id): PDOStatement
    {
        $qeury = $this->dbh->run("DELETE FROM $this->table where id = :id", ['id' => $id]);
        return $qeury;
    }

    // Authenticate user
    public function login($email, $password): bool
    {
        $user = $this->dbh->run("SELECT * FROM $this->table WHERE email = ':email'", ['email' => $email]);
        $user = $user->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['email'];
            return true;
        }
        return false;
    }

    // Check if a user is logged in
    public function isLoggedIn(): bool
    {
        return isset($_SESSION['user_id']);
    }

    public function logout(): void
    {
        session_destroy();
        session_start();
    }
}

$myDb = new DB('cms_db');
$user = new User($myDb);
