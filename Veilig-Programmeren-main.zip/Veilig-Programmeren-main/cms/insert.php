<?php
require 'config.php';
require 'user.php';

$user = new User(new DB('cms_db'));
$userLogin = $user->isLoggedIn();
if (!$userLogin) {
    header("location:login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="user-insert.php" method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
        <input type="text" name="email" placeholder="Email"> <br><br>
        <input type="text" name="password" placeholder="Password"><br><br>
        <input type="submit">
    </form>
</body>

</html>