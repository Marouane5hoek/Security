<?php

$csrfToken = bin2hex(random_bytes(32));
$_SESSION['csrf_token'] = $csrfToken;

echo '<input type="hidden" name="csrf_token" value="' . $csrfToken . '">';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token']) {
        echo 'Verficatie succesvol';
    } else {
        echo 'Verficatie mislukt';
        exit();
    }
}
